package com.vtech.newStudentInfo;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.vtech.newStudentInfo.StudentIdCardImpl;


// Main Method Class
public class StudentIdCardImpl {

	final static String prefix = "STUD";
	static int id = 100;

	public static void main(String[] args) {

		int input = 0;
		
		String stName = null;
		String stClass = null;
		String stBloodGr = null;
		String stDOB = null;

		String generatedID = null;
		String studentName = null;
		String studentStandard = null;
		String studentBloodGr = null;
		String studentBornDate = null;

		boolean flag = true;
		
		List<StudentIdCard> studList = new ArrayList<StudentIdCard>();
		Scanner sc = new Scanner(System.in);
		Validator valid = new Validator();
		try {
			System.out.println("How Many Studnet ID Need To Generate");
			input = sc.nextInt();
		for(int i = 1; i<=input; i++)
		{	
		
			if (input <= 0) {
				throw new Exception("Null, Negative And Zero Will Not Accept ");
			} else {
					
					++id;
					generatedID = valid.idGenerate(prefix, id,input);
					
					System.out.println("Enter Student Name ");
					sc.nextLine();
					stName = sc.nextLine();
					if (valid.isValidStudentName(stName)) {
						studentName = stName;

						System.out.println("Enter Student Class ");
						stClass = sc.next();
						if (valid.isValidStudentClass(stClass)) {
							studentStandard = stClass;

							System.out.println("Enter Student Blood Group ");
							stBloodGr = sc.next();
							if (valid.isValidStudentBloodGroup(stBloodGr)) {
								studentBloodGr = stBloodGr;

								System.out.println("Enter Date Of Birth (Ex : MM-DD-YYYY) ");
								stDOB = sc.next();
								if (stDOB.isEmpty()) {
									System.out.println("Enter Valid Date Of Birth");
									flag = false;
									break;
								} else {
									studentBornDate = valid.validateStudentDOB(stDOB);
								}

							} else {
								System.out.println("Enter Valid Blood Group");
								flag = false;
								break;
							}

						} else {
							System.out.println("Enter Valid Student Class");
							flag = false;
							break;
						}
					} else {
						System.out.println("Please Enter Valid Name..!!");
						flag = false;
						break;
					}
				
					StudentIdCard student1 = new StudentIdCard(generatedID, studentName, studentStandard, studentBloodGr, studentBornDate);
			
					studList.add(student1); // Object1 Added in List
			}
			
			}
			System.out.println();
			System.out.println("\t\t  **********************************");
			System.out.println("\t\t  Generated Student ID Cards are : ");
			if (flag == true) {
				for (StudentIdCard s : studList) {
					s.diplayStudnetIdDetails();
				}
					// id++;
			}
		
		} catch (InputMismatchException ime) {
			System.out.println("Invalid Input : Please Enter Positive Number Only, Try Again..!!");
			flag = false;
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}		
		
		
		
		
		}
	}

